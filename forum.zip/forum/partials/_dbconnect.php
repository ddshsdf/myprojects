<?php

$servername = "localhost";
$username ="root";
$password = "";
$database = "discuss";

$conn = mysqli_connect($servername, $username, $password, $database);



?>



