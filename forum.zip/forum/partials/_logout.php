<?php
session_start();
echo "you logging out. please out...";

session_destroy();
header("location: /forum");

?>